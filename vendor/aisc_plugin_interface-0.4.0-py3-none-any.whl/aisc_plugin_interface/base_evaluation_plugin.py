import copy
import inspect
import logging
import textwrap
from abc import ABC, abstractmethod
from collections.abc import Iterable, Sized
from typing import (
    Any,
    get_args,
    get_origin,
    Callable,
    Tuple,
    TypeAlias,
    TypeVar,
    Generic,
    final,
    Type,
    Self,
)

from pydantic import BaseModel, Field

from aisc_plugin_interface.models.datashape import DataShape
from aisc_plugin_interface.models.llm import LLMConfig
from aisc_plugin_interface.helpers import HelperModel, helper_input_name, helper_roles_of
from aisc_plugin_interface.models.resource import ResourceConfig
from aisc_plugin_interface.decorators.evaluation_input import InputDefinition
from aisc_plugin_interface.models.project_config_definition import ProjectConfigDefinition
from aisc_plugin_interface.utils import classproperty
from aisc_plugin_interface.models.task import TaskProgress
from aisc_plugin_interface.input_providers.base_input_provider import BaseInputProvider
from aisc_plugin_interface.models.measure import Measure, MetricVisualization, ChartType
from aisc_plugin_interface.model_session import ModelSession

ProgressCallback: TypeAlias = Callable[[TaskProgress], None]
ArtifactCallback: TypeAlias = Callable[[str, bytes], None]


class PluginFeatureFlags(BaseModel):
    can_parse_config_from_dataset: bool = Field(
        False, description="Show the dataset dropdown"
    )
    show_dimensions_visualisation: bool = Field(
        False, description="Show the dimensions visualisation on the results page"
    )
    extra: dict = Field({}, description="Additional feature flags")


class BaseEvaluationPlugin[T: BaseModel](ABC):
    """
    Base class for evaluation plugins.
    A plugin inherits from it and gives the Pydantic model of its configuration form as ``T``.

    Example:
        class MyPlugin(BaseEvaluationPlugin[MyConfigModel]):
            ...
    """

    # UI Schema for RJSF (react-jsonschema-form) to customize form appearance
    form_ui_schema: dict = {}

    # The plugin name that will be displayed in the UI
    plugin_name: str | None = None

    # Optional Markdown description shown on the plugin config page.
    # Allows basic formatting (headings, lists, bold, code blocks).
    description: str = ""

    # Controls the icon displayed in the plugin list.
    # Use a Material Design icon name https://fonts.google.com/icons
    ui_icon: str | None = None

    _input_definitions: list[InputDefinition] = []
    _input_provider_types: dict[str, Type[BaseInputProvider]] = {}
    _project_config_definitions: list[ProjectConfigDefinition] = []

    def __init__(self):
        self._input_provider_instances: dict[str, BaseInputProvider] = {}
        self._project_settings: dict[str, Any] = {}
        self._progress_callback: ProgressCallback | None = None
        self._artifact_callback: ArtifactCallback | None = None
        self._logger = None

    @classmethod
    def is_direct_subclass(cls: type[Self]) -> bool:
        return BaseEvaluationPlugin in cls.__bases__

    @classproperty
    def display_name(cls: type[Self]) -> str:
        """
        Returns a display name for the plugin.

        If the class defines a `plugin_name` attribute, its value is returned.
        If not, the class's name (`cls.__name__`) is used as a fallback.
        """
        # A subclass of another plugin does not inherit its parent's plugin_name: it shows its own
        # class name unless it sets plugin_name itself.
        plugin_name = cls.plugin_name
        default = cls.__name__

        if cls.is_direct_subclass():
            return plugin_name or default
        else:
            if plugin_name is None:
                return default
            # avoid using the plugin name that was set for the parent plugin
            for base in cls.__bases__:
                if (
                    issubclass(base, BaseEvaluationPlugin)
                    and plugin_name == base.plugin_name
                ):
                    return default
            return plugin_name

    @property
    def logger(self):
        """
        Returns the logger of this plugin class, named "<module> - <class name>".
        """
        if self._logger is None:
            cls = self.__class__
            self._logger = logging.getLogger(f"{cls.__module__} - {cls.__name__}")
        return self._logger

    @property
    def feature_flags(self) -> PluginFeatureFlags:
        """
        Controls UI behavior on the frontend.
        Override this property in your subclass to change defaults.
        """
        return PluginFeatureFlags()

    @property
    def input_definitions(self) -> list[InputDefinition]:
        """
        Controls the evaluation input form at evaluation creation
        """
        return self._input_definitions

    @property
    def project_config_definitions(self) -> list[ProjectConfigDefinition]:
        return self._project_config_definitions

    @property
    def display_icon(self) -> str:
        """
        Controls the icon displayed in the plugin list.
        Use a Material Design icon name
        https://fonts.google.com/icons

        For a new plugin, either redefine this property, or set the class attribute `ui_icon`
        """
        return self.ui_icon or "extension"

    @property
    def help_text(self) -> str:
        """
        The resolved Markdown description shown on the plugin config page.

        Common leading whitespace is removed so descriptions written as an
        indented triple-quoted string are NOT rendered as a Markdown code block.
        """
        return textwrap.dedent(self.description).strip()

    @property
    def config_type(self) -> type[T]:
        """
        Retrieves the Pydantic model type used for plugin configuration.
        """
        for base in getattr(self.__class__, "__orig_bases__", []):
            if get_origin(base) is BaseEvaluationPlugin:
                return get_args(base)[0]
        raise TypeError("Could not determine Config type T")

    def get_metrics(self) -> list[str]:
        """
        Returns a list of all metric names defined in this plugin via the @metric decorator.
        """
        metrics = []
        for name, method in inspect.getmembers(self, predicate=inspect.ismethod):
            if hasattr(method, "metric_name"):
                metrics.append(method.metric_name)
        return metrics

    def get_metric_visualizations(self, config_data: dict) -> list[MetricVisualization]:
        """
        Returns a list of MetricVisualization objects to render a list of
        visualizations on the front end and the metrics to display for each

        The config_data could be used to define specific visualizations from the config

        By default, returns a single visualization (TABLE) with all metrics
        """
        return [
            MetricVisualization(chart_type=ChartType.TABLE, metrics=self.get_metrics())
        ]

    def export_metrics(self, *args, **kwargs) -> list[Measure]:
        """
        Executes all methods decorated with @metric and aggregates their results.
        """
        results: list[Measure] = []
        for name, method in inspect.getmembers(self, predicate=inspect.ismethod):
            if hasattr(method, "metric_name"):
                metric_measures: list[Measure] = method(*args, **kwargs)
                results.extend(metric_measures)
        return results

    @abstractmethod
    def evaluate(self, config_data: dict) -> Any:
        """
        The main execution logic of the plugin.
        Developers should process the dataset/model here and return an intermediate result
        that will be passed to the metric methods.
        """
        raise NotImplementedError

    @final
    def _set_progress_callback(
        self, progress_callback: ProgressCallback | None
    ) -> None:
        """
        Internal: the evaluation runtime (the eval worker) sets where progress reports go.
        Plugin implementations must not call or override this.
        """
        if progress_callback is not None and not callable(progress_callback):
            raise TypeError("Progress sink must be callable or None")
        self._progress_callback = progress_callback

    @final
    def report_progress(self, task_progress: TaskProgress) -> None:
        """
        Report progress to the evaluation runtime.
        Does nothing when the runtime has set no progress callback.
        """
        if self._progress_callback is None:
            return
        self._progress_callback(task_progress)

    @final
    def progress_bar(
        self,
        iterable,
        *,
        total: int | None = None,
        desc: str | None = None,
        start: int = 0,
        with_index: bool = False,
        extra: dict | None = None,
    ) -> "ProgressBar":
        """
        Wrap an iterable to yield items (optionally with index)
        while emitting progress for each item that is processed.

        Returns a ProgressBar yielding items (or index, item) with automatic progress reporting.

        Args:
            iterable: Items to iterate.
            total: Optional total length.
            desc: Label.
            start: Enumeration start.
            with_index: Yield index with items.
            extra: Extra progress fields.
        """
        return ProgressBar(
            iterable=iterable,
            plugin=self,
            total=total,
            desc=desc,
            start=start,
            with_index=with_index,
            extra=extra,
        )

    @final
    def _set_artifact_callback(
        self, artifact_callback: ArtifactCallback | None
    ) -> None:
        """Internal: called by the evaluation runtime to hook into artifact uploading."""
        self._artifact_callback = artifact_callback

    @final
    def upload_artifact(self, name: str, content: bytes) -> None:
        """
        Upload a file as an artifact of the run.
        Without an artifact callback (outside a run) the file is dropped with a warning.
        """
        if self._artifact_callback:
            self._artifact_callback(name, content)
        else:
            self.logger.warning(
                f"Artifact callback not configured. Dropping artifact: {name}"
            )

    def set_input_content(self, name: str, file_content: bytes | None) -> None:
        """
        Called by the runtime. Instantiates the provider declared with @evaluation_input.
        """
        provider_cls = self._input_provider_types.get(name)
        if provider_cls and file_content is not None:
            self._input_provider_instances[name] = provider_cls(file_content)

    def _replace_input_data(self, name: str, data: Any) -> None:
        """Put already-parsed data in place of an input's (@dataset_through_target's enriched table):
        not through the provider's parser, which reads the input's own file format."""
        provider = self._input_provider_instances.get(name)
        if provider is not None:
            provider._data = data

    def get_input_data(self, name: str) -> Any | None:
        """
        Get data from InputProvider using name set in evaluation_input decorator
        """
        provider = self._input_provider_instances.get(name)
        if provider is None:
            return None
        return provider.get_data()

    def get_input_datashape(self, name: str) -> DataShape | None:
        """
        Return the datashape input parsed into the `DataShape` pydantic model.
        """
        payload = self.get_input_data(name)
        if payload is None:
            return None
        return DataShape.from_payload(payload)

    def get_llm_config(self, name: str, default: LLMConfig | None = None) -> LLMConfig | None:
        """
        Return the llm input parsed into the `LLMConfig` pydantic model.
        """
        payload = self.get_input_data(name)
        if payload is None:
            return default
        try:
            return LLMConfig.model_validate(payload)
        except Exception:
            return default

    def helper(self, role: str) -> HelperModel | None:
        """
        Return the helper model declared with @helper_model for ``role``, its key read from the
        project secret's environment variable. None when the run binds no model to an optional role;
        a bound model the plugin cannot use (malformed, no endpoint or model, its secret absent) raises.
        """
        if role not in helper_roles_of(type(self)):
            raise ValueError(f"{type(self).__name__} declares no helper model {role!r}")
        name = helper_input_name(role)
        payload = self.get_input_data(name)
        if payload is None:
            if any(d.name == name and d.required for d in self.input_definitions):
                raise ValueError(f"the helper model {role!r} is required but the run binds none")
            return None
        try:
            config = LLMConfig.model_validate(payload)
        except Exception:
            # the validation message may quote the input's values: name the role only
            raise ValueError(f"the helper model {role!r} has a malformed input") from None
        for part in ("endpoint_url", "model"):
            if not getattr(config, part):
                raise ValueError(f"the helper model {role!r} is bound without a {part}")
        api_key = None
        if config.secret_key:
            api_key = self.get_secret(config.secret_key)
            if api_key is None:
                raise ValueError(f"the helper model {role!r} needs the project secret {config.secret_key!r},"
                                 " which the run does not provide")
        return HelperModel(role=role, endpoint_url=config.endpoint_url, model=config.model, api_key=api_key)

    def assessed_model(self, outputs: dict | None = None) -> "ModelSession":
        """
        Return the model this run assesses, with ``predict(rows)`` and ``predict_proba(rows)``: the local
        ONNX file when the run binds the plugin's local model input, the AI card target (through its
        connection) when it binds the target. Both bound, or neither, raises ValueError. ``predict`` gives
        the card target's own label values (what its answer carries at the declared label path), and
        class indices (0, 1, ...) for the local model, when the ONNX model has a probability output.

        ``outputs`` (same keys as ``model_session(outputs=...)``) replaces the declared outputs for this
        session only, for a card target whose answer fields come from the run's config. It is validated
        like a declaration (ValueError naming the key); a local session ignores it. A card target is
        scored as a binary classifier: ``outputs["classes"]`` above 2 raises. ``predict_proba`` on a card
        session without a probability path raises; ``predict`` with only a probability path returns 0 or
        1, the more probable class.
        """
        from aisc_plugin_interface.model_session import session_for

        return session_for(self, outputs)

    def get_resource_config(self, name: str, default: ResourceConfig | None = None) -> ResourceConfig | None:
        """
        Return the resource input parsed into the `ResourceConfig` pydantic model.
        """
        payload = self.get_input_data(name)
        if payload is None:
            return default
        try:
            return ResourceConfig.model_validate(payload)
        except Exception:
            return default

    @final
    def _set_project_settings(self, settings: dict[str, Any]) -> None:
        """Internal: called by the evaluation runtime before plugin execution."""
        self._project_settings = copy.deepcopy(settings)

    def get_project_setting(self, key: str, default: Any = None) -> Any:
        """Return a non-secret project setting by its immutable project key."""
        return copy.deepcopy(self._project_settings.get(key, default))

    def require_project_setting(self, key: str) -> Any:
        """Return a non-secret project setting or raise when it is unavailable."""
        if key not in self._project_settings:
            raise KeyError(f"Required project setting '{key}' is not available")
        return copy.deepcopy(self._project_settings[key])

    def get_secret(self, key: str, default: str | None = None) -> str | None:
        """Read a secret injected into the isolated plugin process environment."""
        import os

        return os.environ.get(self._secret_environment_name(key), default)

    def require_secret(self, key: str) -> str:
        """Read a required secret or raise when it is unavailable."""
        value = self.get_secret(key)
        if value is None:
            raise KeyError(f"Required secret '{key}' is not available")
        return value

    @staticmethod
    def _secret_environment_name(key: str) -> str:
        return "AISC_SECRET_" + "".join(
            character.upper() if character.isalnum() else "_"
            for character in key
        )

    def get_datashape(self, key: str) -> DataShape:
        """Returns the datashape of the evaluation plugin."""
        datashape_payload = self.get_project_setting(key)
        datashape = DataShape.from_payload(datashape_payload)
        return datashape

    def get_config_form_schema(self) -> dict:
        """
        Generates a JSON Schema from the Pydantic config model for the frontend UI.
        """
        return self.config_type.model_json_schema(mode="validation")

    def validate_config_form_data(self, config_form_data: dict) -> T:
        """
        Validates incoming form data from frontend UI/backend DB against the Pydantic config model.
        """
        return self.config_type.model_validate(config_form_data)

    def get_config_form_ui_schema(self) -> dict:
        """
        Returns a deep copy of the UI schema for form customization.
        """
        return copy.deepcopy(self.form_ui_schema)

    def form_schema_to_internal(self, form_schema: T) -> dict:
        """
        Optional: Converts the validated Pydantic model used for the UI form
                  into a dict for internal use
        This can be overridden to add/change the structure of the input config data
        for use in the evaluate method
        """
        return form_schema.model_dump()

    def get_full_schema(self) -> Tuple[dict, dict]:
        """Return the config form's JSON schema and UI schema, as declared."""
        return self.get_config_form_schema(), self.get_config_form_ui_schema()

    # form_data may be incomplete, so it is not validated against the config model:
    # an override must check the fields it uses.
    def on_config_change(self, form_data: T | None) -> Tuple[T | None, dict, dict]:
        """
        Hook called whenever the user changes a form value.
        Allows the plugin to dynamically update the schema (e.g. drop downs),
        the data (e.g. auto-fill), or the UI (e.g. hide fields).
        """
        schema, ui_schema = self.get_full_schema()
        return form_data, schema, ui_schema

    def parse_config_from_dataset(self, file_content: bytes) -> dict | None:
        """
        Optional: Try to parse a valid config from the dataset.
        Use a InputProvider to read the file contents
        """
        return None


Item = TypeVar("Item")


class ProgressBar(Generic[Item]):
    """
    Iterator that wraps an iterable, yielding each item (and optionally its index)
    and reporting progress via a plugin.

    Each emit reports the progress for the current item that is processed.

    Args:
        iterable: Items to iterate over.
        plugin: Receives progress reports (must implement `report_progress`).
        total: Length of iteration (inferred if not given).
        desc: Progress label.
        start: Enumeration start index.
        with_index: Yield (index, item) pairs if True.
        extra: Extra fields for progress payloads.
    """

    def __init__(
        self,
        iterable: Iterable[Item],
        *,
        plugin: BaseEvaluationPlugin,
        total: int | None = None,
        desc: str | None = None,
        start: int = 0,
        with_index: bool = False,
        extra: dict | None = None,
    ):
        self._start = start
        self._with_index = with_index

        if total is None:
            if isinstance(iterable, Sized):
                total = len(iterable)
            else:
                iterable = list(iterable)
                total = len(iterable)
        self._total = total

        self._desc = desc or ""
        self._extra = {} if extra is None else extra.copy()

        self._report_progress = getattr(plugin, "report_progress", None)

        self._enumerated_iter = enumerate(iterable, start=self._start)

        self.emit(0)

    @property
    def desc(self) -> str:
        return self._desc

    def set_description(self, description: str):
        self._desc = description

    @property
    def extra(self) -> dict:
        return self._extra

    def set_extra(self, fields: dict) -> None:
        self._extra.update(fields)

    def emit(self, i: int):
        """
        Report progress for index `i` using the plugin.
        """
        if self._report_progress and self._total:
            progress = min(float(min(i, self._total)) / self._total, 1.0)
            payload = {
                "iteration": int(i),
                "total": self._total,
            }
            if self._desc:
                payload["desc"] = self._desc
            if self._extra:
                payload.update(self._extra)
            self._report_progress(
                TaskProgress(
                    progress=progress,
                    extra=payload,
                )
            )

    def __len__(self) -> int:
        return self._total

    def __iter__(self) -> Self:
        return self

    def __next__(self) -> Item | tuple[int, Item]:
        """
        Yield the next item (and index if requested),
        emitting progress for the current item being processed.

        Raises:
            StopIteration when exhausted.
        """
        idx, item = next(self._enumerated_iter)

        self.emit(idx - self._start + 1)
        return (idx, item) if self._with_index else item
