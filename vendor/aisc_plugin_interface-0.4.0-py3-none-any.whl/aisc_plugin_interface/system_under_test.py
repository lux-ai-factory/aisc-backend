"""Declare the system under test a plugin's tool calls, and the protocol(s) the tool speaks.

    @system_under_test(protocols=("openai",),
                       fields={"target.base_url": "base_url", "target.api_key": "api_key", "target.model": "model"})
    class MyPlugin(BaseEvaluationPlugin): ...

The plugin gets a resource input (``system`` by default) that the evaluation form fills with a
connection from Manage → Connections. When a run has one bound, the platform issues the run a key for
that connection and the declared config fields and environment variables are set, for the length of
``evaluate``, to the platform's endpoint for the first protocol listed: the tool keeps connecting the
way it always does and reaches the connection. Whatever the connection is (REST, OpenAI-compatible,
A2A agent, OIP model server), the platform translates.

Roles, by protocol:
    aisc    ask_url, api_key                (POST {input, history} -> {output, refused, ...})
    openai  base_url, model, api_key        (Chat Completions, non-streaming)
    a2a     agent_card_url, rpc_url, api_key (A2A 1.0 JSON-RPC; 0.3 method names answered too)
    oip     base_url, model, api_key        (Open Inference Protocol, KServe V2 REST)

A tool written against AISC directly can use ``connections.EndpointClient.for_input`` instead.
"""
from __future__ import annotations

import copy
import functools
import json
import os
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

# NoEndpoint and _issue_run_key live in connections; their names stay here, and @system_under_test looks
# _issue_run_key up in this module when it runs, so a test can replace it here
from aisc_plugin_interface.connections import BadReference, NoEndpoint, _issue_run_key, reference_of  # noqa: F401
from aisc_plugin_interface.targets import is_target, parse_target
from aisc_plugin_interface.decorators.evaluation_input import evaluation_input
from aisc_plugin_interface.models.evaluation_input import InputType

#: The evaluation's target: the system, or one of its AI card's components. A
#: ``connection:<pid>/<name>`` value (a connection bound directly, without a target) is accepted too.
SYSTEM_INPUT = "target"

ROLES = {
    "aisc": ("ask_url", "api_key"),
    "openai": ("base_url", "model", "api_key"),
    "a2a": ("agent_card_url", "rpc_url", "api_key"),
    "oip": ("base_url", "model", "api_key"),
}

#: What a plugin may need from its target's endpoint beyond a single answer. The platform's endpoint
#: carries text and a history; a run-key answer may list more (`capabilities`).
CAPABILITIES = ("text", "history", "tools", "logprobs")
CARRIED_BY_DEFAULT = ("text", "history")


def target_access_of(cls) -> str | None:
    """How a plugin class gets what it assesses: "endpoint" (@system_under_test), "inputs"
    (@assesses_inputs), "dataset_through_target" (@dataset_through_target), or None when it declares
    nothing (the conformance check fails it). ``target_access_required`` says whether a run needs
    the target's endpoint."""
    return getattr(cls, "target_access", None)


def declaring_base(cls, *attributes: str):
    """The nearest base class that sets one of ``attributes`` itself, or None."""
    return next((base for base in cls.__mro__[1:] if any(a in base.__dict__ for a in attributes)), None)


def inherited_declaration(cls, base) -> ValueError:
    return ValueError(f"{cls.__name__}: it inherits what {base.__name__} assesses; declare it on one class only")


def _one_declaration(cls, access: str) -> None:
    """A class states how it gets what it assesses once: one of these decorators, or @assesses (whose
    card builders apply them before it records the kinds). A subclass of an @assesses class inherits
    its declaration and may not restate it."""
    base = declaring_base(cls, "target_kinds")
    if base is not None:
        raise inherited_declaration(cls, base)
    if target_access_of(cls) not in (None, access) or "target_kinds" in cls.__dict__:
        raise ValueError(f"{cls.__name__}: declare one of @assesses, @system_under_test, @assesses_inputs or"
                         " @dataset_through_target, not two")


def assesses_inputs():
    """Class decorator for a plugin that only reads its inputs (datasets, models, files) and calls no
    live system: nothing changes at run time, the declaration is what the conformance check reads."""
    def decorator(cls):
        _one_declaration(cls, "inputs")
        cls.target_access = "inputs"
        cls.target_access_required = False
        return cls
    return decorator


def system_under_test(protocols: tuple[str, ...] | list[str], fields: dict[str, str] | None = None,
                      env: dict[str, str] | None = None, required: bool = True,
                      input_name: str = SYSTEM_INPUT,
                      label: str = "Target of the assessment (the system, or one of its components)",
                      needs: tuple[str, ...] | list[str] = ()):
    """Class decorator that points a tool at the run's system under test (see the module docstring).

    ``fields`` maps a config field (dotted for nesting) to a role, ``env`` maps an environment variable
    to a role; every role must belong to the first protocol. ``required`` says whether the tool needs
    an endpoint: when it is False and no target or endpoint is bound, ``evaluate`` runs unchanged.
    ``needs`` lists what the tool needs from the endpoint beyond text (CAPABILITIES): a run whose
    endpoint doesn't carry it is refused before the tool starts, with the reason.
    """
    protocols, needs = tuple(protocols), tuple(needs)
    unknown = [n for n in needs if n not in CAPABILITIES]
    if unknown:
        raise ValueError(f"needs: {', '.join(unknown)} (known: {', '.join(CAPABILITIES)})")
    fields, env = dict(fields or {}), dict(env or {})
    if not protocols or any(p not in ROLES for p in protocols):
        raise ValueError(f"protocols: one or more of {', '.join(ROLES)}")
    if not fields and not env:
        raise ValueError("declare at least one config field or environment variable to fill")
    first = protocols[0]
    for target, role in {**fields, **env}.items():
        if role not in ROLES[first]:
            raise ValueError(f"{target}: {role!r} is not a role of {first} ({', '.join(ROLES[first])})")

    def decorator(cls):
        _one_declaration(cls, "endpoint")
        cls.target_access = "endpoint"
        cls.target_access_required = required
        cls.system_under_test_needs = needs
        # The input is declared optional so that a standalone form without targets is not blocked;
        # inside the Configurator the engine makes every evaluation's target required.
        cls = evaluation_input(name=input_name, label=label, input_type=InputType.RESOURCE, required=False)(cls)
        cls.system_under_test_protocols = protocols
        original = cls.evaluate

        @functools.wraps(original)
        def evaluate(self, config_data: dict) -> Any:
            if self.get_input_data(input_name) is None:
                if required:
                    raise ValueError(f"no system under test: bind a connection to input {input_name!r}")
                return original(self, config_data)
            payload = self.get_input_data(input_name)
            value = payload.get("value") if isinstance(payload, dict) else payload
            legacy = None
            try:
                if is_target(value):
                    pid, key = parse_target(value)
                    try:
                        issued = _issue_run_key(pid, f"targets/{urllib.parse.quote(key, safe=':')}", key)
                    except NoEndpoint:
                        if required:
                            raise
                        return original(self, config_data)
                else:
                    pid, legacy = reference_of(self, input_name)
                    issued = _issue_run_key(pid, f"connections/{urllib.parse.quote(legacy)}", legacy)
            except BadReference as exc:
                raise ValueError(f"system under test: {exc}") from None
            name = issued.get("connection") or legacy or "system"
            carried = tuple(issued.get("capabilities") or CARRIED_BY_DEFAULT)
            missing = [n for n in needs if n not in carried]
            if missing:
                raise ValueError(f"{name} can't be used here: this plugin needs {', '.join(missing)} from its target,"
                                 f" and the endpoint carries {', '.join(carried)}")
            endpoint = issued["endpoints"][first]
            values = {**endpoint, "api_key": issued["key"]}
            config = copy.deepcopy(config_data) if config_data is not None else {}
            for field, role in fields.items():
                _set_dotted(config, field, values[role])
            self.upload_artifact(f"connection-{name}.json", json.dumps({
                "connection": f"connection:{pid}/{name}", "target": issued.get("target"),
                "protocol": first, "endpoint": endpoint,
                "expires_at": issued.get("expires_at"), "fields": sorted(fields), "env": sorted(env)},
                indent=2).encode())
            before = {var: os.environ.get(var) for var in env}
            try:
                for var, role in env.items():
                    os.environ[var] = values[role]
                return original(self, config)
            finally:
                for var, old in before.items():
                    if old is None:
                        os.environ.pop(var, None)
                    else:
                        os.environ[var] = old

        cls.evaluate = evaluate
        return cls

    return decorator


def _set_dotted(config: dict, path: str, value: Any) -> None:
    *parents, leaf = path.split(".")
    node = config
    for key in parents:
        node = node.setdefault(key, {})
    node[leaf] = value


#: the run settings @dataset_through_target reads from a plugin's config, when its form has them
CALLS_AT_ONCE, ROW_LIMIT = "target_calls_at_once", "target_row_limit"
#: The most calls at once a run may ask for: its setting comes from a project member's form, and each
#: call is a thread of the shared worker.
MAX_CALLS_AT_ONCE = 16
PREFIX = "target."


def dataset_through_target(datasets: tuple[str, ...] | list[str], input_name: str = SYSTEM_INPUT,
                           label: str = "Target of the assessment (the system, or one of its components)",
                           required: bool = True):
    """Class decorator for a plugin that analyses tables: before ``evaluate``, every row of each named
    dataset input is sent to the evaluation's target, through its endpoint (the row as the request's
    ``{{input}}``), and each scalar field of the answer is added to the row as ``target.<field>`` (a text
    answer as ``target.answer``; a refusal as ``target.refused`` and ``target.refusal_reason``; a failed
    call as ``target.error``; a field of the answer named like one of these as ``target.answer.<field>``). The plugin then reads the enriched table as if it had been uploaded so.

    Run settings, read from the plugin's config when its form has them: ``target_calls_at_once``
    (default 1) and ``target_row_limit`` (default 0: every row). The answers are saved with the run as
    ``target-answers-<dataset>.csv``. A run without a target that has an endpoint is refused before the
    plugin starts; with ``required=False`` it runs on the uploaded tables as they are (a component with
    no endpoint, such as training data), while any other failure to reach the platform still stops it.
    """
    datasets = tuple(datasets)
    if not datasets:
        raise ValueError("datasets: name at least one dataset input")

    def decorator(cls):
        _one_declaration(cls, "dataset_through_target")
        cls.target_access = "dataset_through_target"
        cls.dataset_through_target_inputs = datasets
        cls.dataset_through_target_required = required
        cls.target_access_required = required
        cls = evaluation_input(name=input_name, label=label, input_type=InputType.RESOURCE, required=False)(cls)
        original = cls.evaluate

        @functools.wraps(original)
        def evaluate(self, config_data: dict) -> Any:
            from aisc_plugin_interface.connections import (
                BadReference, EndpointClient, EndpointNotFound, TargetHasNoEndpoint,
            )
            payload = self.get_input_data(input_name)
            value = payload.get("value") if isinstance(payload, dict) else payload
            if value is None:                                          # not given, or not bound
                if not required:
                    return original(self, config_data)
                raise ValueError("no target: this plugin sends its datasets through the evaluation's target,"
                                 " which needs an endpoint (Manage, Components and connections)")
            try:
                # a target's endpoint, or a connection bound directly (connection:<pid>/<name>)
                client = (EndpointClient.for_target(self, input_name) if is_target(value)
                          else EndpointClient.for_input(self, input_name))
            except TargetHasNoEndpoint as exc:
                if not required:
                    return original(self, config_data)
                raise ValueError(str(exc)) from None
            except (EndpointNotFound, BadReference) as exc:
                raise ValueError(f"target: {exc}") from None
            settings = config_data or {}
            at_once = min(MAX_CALLS_AT_ONCE, max(1, int(settings.get(CALLS_AT_ONCE) or 1)))
            limit = max(0, int(settings.get(ROW_LIMIT) or 0))
            for name in datasets:
                table = self.get_input_data(name)
                if table is None:
                    continue
                merged = _through(client, table, at_once, limit)
                # the plugin gets its table back in the form it had it (a DataFrame, or rows), whatever
                # its input's provider parses; the answers are saved with the run as CSV
                self._replace_input_data(name, _like(table, merged))
                self.upload_artifact(f"target-answers-{name}.csv", _as_csv(merged))
            return original(self, config_data)

        cls.evaluate = evaluate
        return cls

    return decorator


def _rows(table) -> list[dict]:
    if hasattr(table, "to_dict"):                              # a pandas DataFrame
        return table.to_dict(orient="records")
    if isinstance(table, list) and all(isinstance(r, dict) for r in table):
        return [dict(r) for r in table]
    raise ValueError("@dataset_through_target needs a table: a pandas DataFrame or a list of rows")


def _plain(value):
    """A JSON value for a cell: numpy numbers as Python numbers, NaN as null."""
    if hasattr(value, "item"):
        value = value.item()
    if isinstance(value, float) and value != value:
        return None
    return value


#: The columns the wrapper itself writes; a system's own field of the same name goes under ``target.answer.``
_RESERVED = ("refused", "refusal_reason", "error", "answer")


def _sent(value):
    """A cell as the request carries it: a JSON value. Dates and times (pandas Timestamps too) as ISO
    text, a missing time (NaT) as null, a Decimal as a number."""
    from decimal import Decimal

    value = _plain(value)
    if isinstance(value, Decimal):
        return float(value) if value.is_finite() else None
    if hasattr(value, "isoformat"):
        return None if value != value else value.isoformat()          # NaT is not equal to itself
    return value


def _answer_columns(answer) -> dict:
    out = {PREFIX + "refused": bool(answer.refused)}
    if answer.refused:
        out[PREFIX + "refusal_reason"] = answer.refusal_reason
    elif isinstance(answer.text, dict):
        out.update({PREFIX + ("answer." + k if k in _RESERVED else k): v for k, v in answer.text.items()
                    if isinstance(v, (str, int, float, bool)) or v is None})
    else:
        out[PREFIX + "answer"] = answer.text
    return out


def _through(client, table, at_once: int, limit: int) -> list[dict]:
    """The table's rows, each with the target's answer as more columns."""
    from concurrent.futures import ThreadPoolExecutor
    from aisc_plugin_interface.connections import EndpointError

    rows = _rows(table)
    if limit:
        rows = rows[:limit]

    def one(row):
        """(columns, whether the call failed)."""
        try:
            return _answer_columns(client.ask({k: _sent(v) for k, v in row.items()})), False
        except EndpointError as exc:
            return {PREFIX + "refused": False, PREFIX + "error": str(exc)}, True

    with ThreadPoolExecutor(max_workers=at_once) as pool:
        outcomes = list(pool.map(one, rows))
    answers = [columns for columns, _ in outcomes]
    if rows and all(failed for _, failed in outcomes):
        raise RuntimeError(f"the target answered none of the {len(rows)} rows: {answers[0][PREFIX + 'error']}")
    return [{**{k: _plain(v) for k, v in row.items()}, **answer} for row, answer in zip(rows, answers)]


def _columns(merged: list[dict]) -> list[str]:
    return list(dict.fromkeys(k for r in merged for k in r))


def _as_csv(merged: list[dict]) -> bytes:
    """The enriched rows as CSV, for the run's artifact.

    The target's answers and the dataset are untrusted text, and the file is meant to be opened in a
    spreadsheet: any text cell (or column name) a spreadsheet would run as a formula gets a leading
    single quote (the OWASP CSV injection rule). Numbers are written as they are.
    """
    import csv
    import io

    columns = _columns(merged)
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow([_inert(c) for c in columns])
    writer.writerows([_inert(row.get(c, "")) for c in columns] for row in merged)
    return buffer.getvalue().encode()


def _inert(cell):
    """A text cell a spreadsheet would run as a formula, with a leading quote; anything else unchanged."""
    if isinstance(cell, str) and cell[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + cell
    return cell


def _like(table, merged: list[dict]):
    """The enriched rows in the form the table had: a DataFrame for a DataFrame, else a list of rows."""
    if hasattr(table, "to_dict"):
        import pandas as pd

        return pd.DataFrame(merged, columns=_columns(merged))
    return merged
